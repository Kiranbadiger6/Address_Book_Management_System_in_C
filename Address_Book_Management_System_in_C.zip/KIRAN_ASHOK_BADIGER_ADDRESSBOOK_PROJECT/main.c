/******************************************************************************
 *                     ADDRESS BOOK
 *
 * Project Name : Address Book Management
 * Language     : C Programming
 * 
 * Name         : Kiran Ashok Badiger
 * Roll Number  : 26005A-018  
 * Date         : 17-06-2026     
 *
 * Description:
 * It allows users to create, search, edit, delete, and list contacts.
 * Contact details are stored permanently in a CSV file so that data
 * persists even after the program is terminated and restarted.
 */

#include <stdio.h>
#include "contact.h"

#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define PURPLE "\033[1;35m"
#define RESET   "\033[0m"
#define YELLOW "\033[1;33m"


int main() 
{
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book


    do 
    {
        printf(YELLOW "\n-----------------------Address Book Menu:-------------------------------------\n" RESET);
        printf(GREEN "1. Create contact\n" RESET);
        printf(GREEN "2. Search contact\n" RESET);
        printf(GREEN "3. Edit contact\n" RESET);
        printf(GREEN "4. Delete contact\n" RESET);
        printf(GREEN "5. List all contacts\n" RESET);
        printf(GREEN "6. Save and Exit\n" RESET);
        printf(GREEN "7. Exit\n" RESET);
        
        printf("\nEnter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) 
        {
            case 1:
                createContact(&addressBook);
                break;
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:          
                 listContacts(&addressBook);
                 break;
            case 6:
                printf("Saving and Exiting...\n");
                saveContactsToFile(&addressBook);
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);
    
    return 0;
}
