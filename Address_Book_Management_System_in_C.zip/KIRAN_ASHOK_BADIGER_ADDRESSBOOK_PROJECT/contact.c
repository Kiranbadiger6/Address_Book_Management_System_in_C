#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "contact.h"
#include "file.h"


#define RED     "\033[1;31m"
#define GREEN   "\033[1;32m"
#define PURPLE "\033[1;35m"
#define RESET   "\033[0m"


void listContacts(AddressBook *addressBook) 
{
    if(addressBook->contactCount == 0)
    {
      printf("No Contacts Available\n");
      return;
    }
    printf("\n----------Contact list-------------\n");
    // Outer loop of Bubble Sort
    for(int i = 0; i < addressBook->contactCount - 1; i++){
        // Inner loop of Bubble Sort
        for(int j = 0; j < addressBook->contactCount - i - 1; j++){    // After every pass, largest element moves to end,// So inner loop reduces by i
            if(strcasecmp(addressBook->contacts[j].name,
                      addressBook->contacts[j+1].name) > 0){
                Contact temp = addressBook->contacts[j]; 
                addressBook->contacts[j] = addressBook->contacts[j+1]; 
                addressBook->contacts[j+1] = temp;
            }
        }
    }
    printf("\n+----+----------------------+--------------+--------------------------------------+\n");
printf("| %-2s | %-20s | %-12s | %-36s |\n",
       "No", "Name", "Phone No", "Email ID");
printf("+----+----------------------+--------------+--------------------------------------+\n");

for(int i = 0; i < addressBook->contactCount; i++)
{
    printf("| %-2d | %-20s | %-12s | %-36s |\n",
           i + 1,
           addressBook->contacts[i].name,
           addressBook->contacts[i].phone,
           addressBook->contacts[i].email);
}

printf("+----+----------------------+--------------+--------------------------------------+\n");
}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    // populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);
}

void saveAndExit(AddressBook *addressBook) {
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}
int is_phone_unique(AddressBook *ab, const char *phone)
{
    for (int i = 0; i < ab->contactCount; i++) {
        if (strcmp(ab->contacts[i].phone, phone) == 0)
            return 0;
    }
    return 1;
}

int validate_name(char *name)
{
    if(strlen(name) == 0){
        printf(RED "ERROR : Name cannot be empty.\n" RESET);
        return 0;
    }
    for(int i=0;name[i] != '\0';i++){
        char c = name[i];
        if(!isalpha((unsigned char) c ) && c != ' ' && c != '.'){
            printf(RED "ERROR : Name can only contains letters,space,or dots.\n"RESET);
            return 0;
        }
    }
    return 1;
}

int validate_phone(char *phone,AddressBook *addressBook)
{
    int i;
    if(strlen(phone) != 10){
        printf(RED "ERROR : Phone number must be 10 Digits.\n"RESET);
        return 0;
    }
    for(i=0;phone[i] != '\0';i++){
        if(!isdigit(phone[i])){
            return 0;
        }
    }
     if (!is_phone_unique(addressBook, phone)) {
        printf(RED "[Error] This phone number already exists.\n" RESET);
        return 0;
    }
    return 1;
}
int validate_email(char *mail,AddressBook *addressBook)
{
    int i, at = -1, dot = -1;
    if(!(mail[0] >= 'a' && mail[0] <= 'z')){
        printf(RED "Error: Email should start with a lowercase alphabet\n" RESET);
        return 0;
    }
    for(i = 0; mail[i] != '\0'; i++){
        if(mail[i] == '@'){
            at = i;
            break;
        }
    }if(at == -1){
        printf(RED "Error: '@' not found\n" RESET);
        return 0;
    }
    for(i = at + 1; mail[i] != '\0'; i++){
        if(strncmp(&mail[i], ".com", 4) == 0){
            dot = i;
            break;
        }
    }if(dot == -1){
        printf(RED "Error: '.com' not found\n" RESET);
        return 0;
    }
    if(dot == at + 1){
        printf(RED "Error: No domain name between '@' and '.com'\n" RESET);
        return 0;
    }
    if(strcmp(&mail[dot], ".com") != 0)
    {
        printf(RED "Error: Invalid characters after '.com'\n" RESET);
        return 0;
    }
    for(int i=0;i<addressBook->contactCount;i++)
{
    if(strcmp(addressBook->contacts[i].email, mail) == 0)
    {
        printf(RED "Email already exists\n" RESET);
        return 0;
    }
}

    return 1;
}


void createContact(AddressBook *addressBook)
{
    if(addressBook->contactCount >= 100){
        printf("Address Book Limit if Full.\n");
        return;
    }
    char name[20];
    char phone[11];
    char mail[50];

    while(1){
        printf("Enter the name : ");
        scanf(" %[^\n]", name);
        if(validate_name(name)){
            break;
        }
    }

    while(1){
        printf("Enter the phone : ");
        scanf("%10s", phone);
        if(validate_phone(phone,addressBook)){
            break;
        }
    }
    while(1){
        printf("Enter the Email : ");
        scanf(" %49s",mail);
        if(validate_email(mail,addressBook)){
            break;
        }
    }
    int index = addressBook->contactCount;

    strcpy(addressBook->contacts[index].name, name);
    strcpy(addressBook->contacts[index].phone, phone);
    strcpy(addressBook->contacts[index].email, mail);
    addressBook->contactCount++;

    printf(GREEN "\nContact added Succesfully.\n" RESET);

}

void searchContact(AddressBook *addressBook) 
{
    int choice;          
    char search[50];  
    int found = 0;   

    // Display search menu
    printf("\nSearch Menu:\n\n");
    printf("1. Search by Name\n");
    printf("2. Search by Phone\n");
    printf("3. Search by Email\n");
    printf("Enter choice: ");
    scanf("%d", &choice);

    // Get value to search
    printf("\nEnter search value: ");
    scanf(" %[^\n]", search);

    printf("\n-------------------------------------------------------------------------------------------------------\n");
    printf("| %-3s | %-20s | %-12s | %-35s |\n",
       "No", "Name", "Phone No", "Email ID");
    printf("-------------------------------------------------------------------------------------------------------\n");

    // Loop through all contacts
    for (int i = 0; i < addressBook->contactCount; i++)
    {
        Contact *c = &addressBook->contacts[i];

        // Compare using strcmp
        if ((choice == 1 && strstr(c->name, search) != NULL) ||
            (choice == 2 && strstr(c->phone, search) != NULL) ||
            (choice == 3 && strstr(c->email, search) != NULL))
        {
            // If match found
            printf(GREEN "| %-3d | %-20s | %-12s | %-35s |\n" RESET,
            i + 1,
            addressBook->contacts[i].name,
            addressBook->contacts[i].phone,
            addressBook->contacts[i].email);
            found = 1;
        }
    }
    if(found){
        printf("\nContact found Successfully.\n");
    }else{
        printf(RED "Contact Not Found.\n" RESET);
    }
}
void editContact(AddressBook *addressBook)
{
    // First search the contact
    searchContact(addressBook);
    int index;
    printf("Enter the serial number to edit: ");
    scanf("%d", &index);

    index = index - 1;

    if(index == -1)
    {
        printf(RED "cannot edit. Contact not found!\n" RESET);
        return;   // Stop function
    } 

    int choice;

    // Show edit menu
    printf("\nEdit Menu:\n");
    printf("1. Edit Name\n");
    printf("2. Edit Phone\n");
    printf("3. Edit Email\n");
    printf("Enter choice: ");
    scanf("%d", &choice);

    // Get pointer to selected contact
    Contact *c = &addressBook->contacts[index];

    // If user chooses to edit name
    if (choice == 1)
    {
        printf("Enter new name: ");
        scanf(" %[^\n]", c->name);   // Directly update name
        printf(GREEN "Name updated successfully!\n" RESET);
        listContacts(addressBook);
    }
    
    // If user chooses to edit phone
    else if(choice == 2)
    {
        char newphone[20];   // Temporary variable

        while(1)
        {
            printf("Enter new Phone (10 digit): ");
            scanf("%s", newphone);

            // If user enters same phone number of same contact
            if(strcmp(newphone, c->phone) == 0)
            {
                printf(GREEN "Phone updated successfully!\n"RESET);
                break;
            }

            // Validate new phone
            if(validate_phone(newphone, addressBook)) //function call for Phone number validation
            {
                strcpy(c->phone, newphone);   // Copy new phone number
                printf(GREEN "Phone updated successfully!\n" RESET);
                listContacts(addressBook);
                break;
            }

            printf(RED"Invalid or Duplicate phone number! Try again.\n"RESET);
        }
    }    

    // If user chooses to edit email
    else if (choice == 3)
    {
        char newemail[50];   // Temporary variable

        while(1)
        {
            printf("Enter new email: ");
            scanf(" %s", newemail);

            // If user enters same email
            if(strcmp(newemail, c->email) == 0)
            {
                printf(GREEN"Email updated successfully!\n"RESET);
                break;
            }

            // Validate new email
            if(validate_email(newemail,addressBook)) // function call for Email validation
            {
                strcpy(c->email, newemail);   // Copy new email
                printf(GREEN "Email updated successfully!\n"RESET);
                listContacts(addressBook);
                break;
            }

            printf(RED "Invalid or Duplicate Email! Try again.\n" RESET);
        }
    }

    // If wrong menu choice
    else
    {
        printf("Invalid choice!\n");
    }
}

void deleteContact(AddressBook *addressBook)
{
    // First search the contact to delete
    searchContact(addressBook);
    int index;
    printf("Enter the serial number to delete: ");
    scanf("%d", &index);

    index = index - 1;

    // If contact not found
    if(index < 0 || index >= addressBook->contactCount)
    {
        printf(RED "cannot delete. Contact not found!\n" RESET);
        return;   // Stop function
    } 

    // Shift all contacts one position left
    // This removes the selected contact
    for (int i = index; i < addressBook->contactCount - 1; i++)
    {
        addressBook->contacts[i] = addressBook->contacts[i + 1];
    }

    // Reduce total contact count
    addressBook->contactCount--;

    printf(GREEN"Contact deleted successfully!\n" RESET);
}
